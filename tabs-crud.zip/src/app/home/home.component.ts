import { Component } from '@angular/core';
export interface PeriodicElement {
  name: string;
  actions: any;
 
}
const ELEMENT_DATA: PeriodicElement[] = [
  {  name: 'Hydrogen', actions: 1.0079 },
  {  name: 'Helium', actions: 4.0026 },
  {  name: 'Lithium', actions: 6.941 },
  {  name: 'Beryllium', actions: 9.0122 },

];

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent {
  displayedColumns: string[] = ['name', 'actions'];
  dataSource = ELEMENT_DATA;
}
